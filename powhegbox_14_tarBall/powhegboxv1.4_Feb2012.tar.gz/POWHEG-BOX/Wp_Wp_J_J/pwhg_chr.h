	character * 20 chr_whichanalysis
	common/pwhg_chr/chr_whichanalysis
