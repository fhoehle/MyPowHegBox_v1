c -*- Fortran -*-
      real * 8 ph_alphaem,ph_Zmass,ph_Zwidth,ph_Wmass,ph_Wwidth,ph_cthw,
     $     ph_sthw,ph_sthw2,ph_Hmass,ph_Hmass2, ph_Hwidth,
     $     ph_Hmass2low,ph_Hmass2high, ph_HmHw,ph_unit_e,
     $     ph_CKM(3,3),ph_GF,ph_topmass,ph_bmass
      common/ph_common/ph_alphaem,ph_Zmass,ph_Zwidth,ph_Wmass,ph_Wwidth
     $     ,ph_cthw,ph_sthw,ph_sthw2,ph_Hmass,ph_Hmass2,
     $     ph_Hwidth,ph_Hmass2low,ph_Hmass2high, ph_HmHw
     $     ,ph_unit_e,ph_CKM,ph_GF,ph_topmass,ph_bmass
      
      
