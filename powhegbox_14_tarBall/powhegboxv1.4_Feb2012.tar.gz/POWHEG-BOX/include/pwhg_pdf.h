c -*- Fortran -*-

      integer pdf_ih1,pdf_ih2,pdf_ndns1,pdf_ndns2
      common/pwhg_pdf/pdf_ih1,pdf_ih2,pdf_ndns1,pdf_ndns2
      save /pwhg_pdf/
