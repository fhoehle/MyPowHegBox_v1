c -*- Fortran -*-

      real * 8 vsymfact
      integer idvecbos1,vdecaymodeZ1,idvecbos2,vdecaymodeZ2
      common/cvecbos/vsymfact,idvecbos1,vdecaymodeZ1,
     1  idvecbos2,vdecaymodeZ2

