c -*- Fortran -*-
      real * 8 ph_alphaem,ph_Zmass,ph_Zmass2,ph_Zwidth,ph_ZmZw,
     1     ph_Wmass,ph_Wmass2,ph_Wwidth,ph_WmWw,ph_cthw,ph_cthw2,
     2     ph_sthw,ph_sthw2,ph_gmu,ph_unit_e, ph_CKM(3,3)
      common/ph_common/
     1         ph_alphaem,ph_Zmass,ph_Zmass2,ph_Zwidth,ph_ZmZw,
     2     ph_Wmass,ph_Wmass2,ph_Wwidth,ph_WmWw,ph_cthw,ph_cthw2,
     3     ph_sthw,ph_sthw2,ph_gmu,ph_unit_e, ph_CKM
