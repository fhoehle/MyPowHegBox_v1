c -*- Fortran -*-

      integer idvecbos1,vdecaymodeWm,idvecbos2,vdecaymodeWp
      common/cvecbos/idvecbos1,vdecaymodeWp,
     1  idvecbos2,vdecaymodeWm

