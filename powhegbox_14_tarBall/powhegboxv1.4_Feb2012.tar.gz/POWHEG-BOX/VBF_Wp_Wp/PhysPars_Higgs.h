c -*- Fortran -*-
      real * 8 ph_Hmass,ph_Hwidth,ph_Hmass2,
     $         ph_Hmass2low,ph_Hmass2high,ph_HmHw
      common/ph_common/ph_Hmass,ph_Hmass2,ph_Hwidth,
     $       ph_Hmass2low,ph_Hmass2high,ph_HmHw
      
      
