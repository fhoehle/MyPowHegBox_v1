      logical zerowidth
      common/ww_widths/zerowidth

