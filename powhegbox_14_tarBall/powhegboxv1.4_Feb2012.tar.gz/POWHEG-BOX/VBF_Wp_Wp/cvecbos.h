c -*- Fortran -*-

      real*8 wsymfact
      integer idvecbos,vdecaymodew1,vdecaymodew2
      common/cvecbos/wsymfact,idvecbos,vdecaymodew1,vdecaymodew2
