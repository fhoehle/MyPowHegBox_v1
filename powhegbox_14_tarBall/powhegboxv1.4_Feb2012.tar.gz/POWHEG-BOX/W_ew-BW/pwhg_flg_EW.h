
      logical flg_inbtilde,flg_inequiv
      common/pwhg_flg/flg_inbtilde,flg_inequiv


   
