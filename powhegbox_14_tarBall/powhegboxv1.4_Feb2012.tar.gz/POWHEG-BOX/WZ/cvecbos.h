c -*- Fortran -*-

      real * 8 vsymfact
      integer vdecaymodeW, vdecaymodeZ
      common/cvecbos/vsymfact,vdecaymodeW,vdecaymodeZ

